<?php

namespace App\Http\Controllers\Tresorerie;

use App\Models\Caisse;
use App\Models\DepenseCaisse;
use App\Models\Fournisseur;
use App\Models\Operation;
use App\Models\User;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;

class DepenseCaisseController extends Controller
{
    public function index()
    {
        $depenses = $this->applyDecaissementVisibility(
            DepenseCaisse::with([
            'caisse',
            'creator',
            'beneficiaire'
        ]),
            Auth::user()
        )->latest()->get();

        return view('tresorerie.depenses', compact('depenses'));
    }

    public function create()
    {
        /** @var User|null $user */
        $user = Auth::user();

        // Les admins et superadmins ont accès à toutes les caisses
        // Les modérateurs doivent avoir la permission tresorerie
        $isAdmin = $user && in_array($user->role, ['admin', 'superadmin'], true);
        $isModerateurTresorerie = $user && in_array($user->role, ['moderator', 'moderateur'], true)
            && $user->hasModulePermission('tresorerie');

        $caissesQuery = Caisse::query();
        if (Schema::hasColumn('caisses', 'est_active')) {
            $caissesQuery->where('est_active', true);
        }

        $caisses = $caissesQuery
            ->when(
                $user && !$isAdmin && !$isModerateurTresorerie,
                function ($query) use ($user) {
                    if (Schema::hasColumn('caisses', 'responsable_id')) {
                        $query->where('responsable_id', $user->id);
                    }
                }
            )
            ->orderBy('nom')
            ->get();

        if ($caisses->isEmpty()) {
            return redirect()->route('tresorerie.caisses.index')
                ->with('warning', 'Aucune caisse active ne vous est attribuée pour créer un décaissement.');
        }

        // Récupérer les opérations approuvées non payées
        // Statuts approuvés en attente de paiement (variantes historiques incluses)
        $approvedStatus = [
            'Approuvé_en_attente_paiement',
            'bon_pour_accord',
            'pret_execution',
            'approuvee',
            'approuve',
            'validée',
            'validee',
            'validé',
            'valide',
            'approved',
        ];

        $operations = collect();
        if (Schema::hasTable('operations') && Schema::hasColumn('operations', 'statut_courant')) {
            $operationsQuery = Operation::query()
                ->where(function ($query) use ($approvedStatus) {
                    $query->whereIn('statut_courant', $approvedStatus)
                        ->orWhereRaw('LOWER(TRIM(statut_courant)) IN (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', [
                            'approuve_en_attente_paiement',
                            'bon_pour_accord',
                            'pret_execution',
                            'approuvee',
                            'approuve',
                            'validée',
                            'validee',
                            'validé',
                            'valide',
                            'approved',
                        ]);
                });

            if (Schema::hasColumn('operations', 'is_paid')) {
                $operationsQuery->where(function ($query) {
                    $query->whereNull('is_paid')->orWhere('is_paid', false);
                });
            }

            $operations = $operationsQuery->latest()->get();
        }

        // Récupérer les factures pour la liaison optionnelle
        $factures = collect();
        try {
            $hasFactures = Schema::hasTable('factures');
            $hasClients = Schema::hasTable('clients');

            $factureNumberColumn = Schema::hasColumn('factures', 'numero_facture') ? 'numero_facture'
                : (Schema::hasColumn('factures', 'numero') ? 'numero' : null);

            $factureAmountRemainingColumn = Schema::hasColumn('factures', 'montant_restant') ? 'montant_restant'
                : (Schema::hasColumn('factures', 'reste_a_payer') ? 'reste_a_payer' : null);

            $factureDateColumn = Schema::hasColumn('factures', 'date_facturation') ? 'date_facturation'
                : (Schema::hasColumn('factures', 'created_at') ? 'created_at' : null);

            $clientNameColumn = null;
            if ($hasClients) {
                foreach (['nom_complet', 'raison_sociale', 'name', 'nom'] as $candidate) {
                    if (Schema::hasColumn('clients', $candidate)) {
                        $clientNameColumn = $candidate;
                        break;
                    }
                }
            }

            $factureColumnsOk = $hasFactures
                && Schema::hasColumn('factures', 'id')
                && Schema::hasColumn('factures', 'statut')
                && $factureNumberColumn
                && $factureDateColumn
                && $factureAmountRemainingColumn;

            if ($factureColumnsOk) {
                $facturesQuery = DB::table('factures')
                    ->select(
                        'factures.id',
                        'factures.' . $factureNumberColumn . ' as numero_facture',
                        'factures.montant_ttc',
                        'factures.' . $factureAmountRemainingColumn . ' as montant_restant',
                        'factures.statut',
                        'factures.' . $factureDateColumn . ' as date_facturation'
                    )
                    ->where(function ($query) {
                        $query->whereIn('factures.statut', ['en_attente', 'en_retard', 'impayee', 'impayée', 'partiellement_payee', 'partiellement_payée', 'non_payee', 'non_payée'])
                            ->orWhereRaw('LOWER(TRIM(factures.statut)) IN (?, ?, ?, ?, ?, ?, ?, ?)', [
                                'en_attente',
                                'en_retard',
                                'impayee',
                                'impayée',
                                'partiellement_payee',
                                'partiellement_payée',
                                'non_payee',
                                'non_payée',
                            ]);
                    })
                    ->where('factures.' . $factureAmountRemainingColumn, '>', 0)
                    ->orderBy('factures.' . $factureDateColumn, 'desc');

                if ($hasClients && $clientNameColumn && Schema::hasColumn('factures', 'client_id') && Schema::hasColumn('clients', 'id')) {
                    $facturesQuery->leftJoin('clients', 'factures.client_id', '=', 'clients.id')
                        ->addSelect('clients.' . $clientNameColumn . ' as client_nom');
                }

                $factures = $facturesQuery->get();
            }
        } catch (\Throwable $e) {
            Log::warning('Chargement des factures ignoré sur décaissement/create (schéma incomplet).', [
                'error' => $e->getMessage(),
                'user_id' => $user?->id,
            ]);
        }

        // Récupérer les fournisseurs actifs
        $fournisseurs = collect();
        if (Schema::hasTable('fournisseurs')) {
            $fournisseurs = Fournisseur::query()
                ->when(Schema::hasColumn('fournisseurs', 'est_actif'), fn($q) => $q->where('est_actif', true))
                ->when(Schema::hasColumn('fournisseurs', 'actif'), fn($q) => $q->where('actif', true))
                ->orderBy(Schema::hasColumn('fournisseurs', 'nom') ? 'nom' : 'raison_sociale')
                ->get();
        }

        return view('tresorerie.decaissements-create', compact('caisses', 'operations', 'factures', 'fournisseurs'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'operation_id' => 'nullable|exists:operations,id',
            'facture_id' => 'nullable|exists:factures,id',
            'fournisseur_id' => 'nullable|exists:fournisseurs,id',
            'date_decaissement' => 'required|date',
            'libelle' => 'required|string|max:255',
            'montant' => 'required|numeric',
            'caisse_id' => 'required|exists:caisses,id',
            'statut' => 'required|string',
            'beneficiaire' => 'required|string|max:255',
            'motif' => 'nullable|string|max:255',
            'responsable' => 'nullable|string|max:255',
            'justification' => 'nullable|string|max:255',
            'notes' => 'nullable|string',
        ]);

        if ((float) $validated['montant'] == 0.0) {
            return back()->withInput()->with('error', 'Le montant ne peut pas etre egal a zero.');
        }

        /** @var User|null $user */
        $user = Auth::user();
        $caisse = Caisse::findOrFail($validated['caisse_id']);

        if (!$user) {
            abort(403, 'Accès non autorisé');
        }

        $this->authorizeCaisseAccess($caisse, $user);

        // Vérifier que la caisse a un solde suffisant
        if ((float) $validated['montant'] > 0 && $caisse->solde_actuel < (float) $validated['montant']) {
            return back()
                ->withInput()
                ->with('error', "Solde insuffisant dans la caisse '{$caisse->nom}'. "
                    . "Solde disponible: " . number_format((float) $caisse->solde_actuel, 0, ',', ' ') . " FCFA, "
                    . "Montant demandé: " . number_format((float) $validated['montant'], 0, ',', ' ') . " FCFA");
        }

        try {
            $depense = DB::transaction(function() use ($validated, $user, $caisse) {
                // Force le statut à 'validé' pour que le décaissement soit immédiat
                $statusToUse = 'validé';

                $depense = DepenseCaisse::create([
                    'operation_id' => $validated['operation_id'] ?? null,
                    'facture_id' => $validated['facture_id'] ?? null,
                    'fournisseur_id' => $validated['fournisseur_id'] ?? null,
                    'reference' => DepenseCaisse::generateReference(), // Générer automatiquement la référence
                    'date_depense' => $validated['date_decaissement'],
                    'libelle' => $validated['libelle'],
                    'montant' => $validated['montant'],
                    'caisse_id' => $validated['caisse_id'],
                    'statut' => $statusToUse,  // Toujours 'validé'
                    'notes' => ($validated['notes'] ?? '') . "\nBénéficiaire: " . $validated['beneficiaire'] . ($validated['motif'] ? "\nMotif: " . $validated['motif'] : ""),
                    'created_by' => $user->id,
                    'createur_id' => $user->id,
                ]);

                // Si une opération est liée, on la marque comme payée
                if (!empty($validated['operation_id'])) {
                    $operation = Operation::find($validated['operation_id']);
                    if ($operation) {
                        $operation->update([
                            'is_paid' => true,
                            'paid_at' => now(),
                            'paid_by' => $user->id,
                            'payment_reference' => $depense->reference
                        ]);

                        // Log de statut
                        \App\Models\OperationStatusLog::create([
                            'operation_id' => $operation->id,
                            'from_status' => $operation->statut_courant,
                            'to_status' => 'payee',
                            'user_name' => $user->name,
                            'user_id' => $user->id,
                            'commentaire' => 'Décaissement effectué via caisse: ' . $depense->reference,
                        ]);
                    }
                }

                return $depense;
            });

            return redirect()->route('tresorerie.decaissements.show', $depense->id)
                ->with('success', 'Décaissement enregistré avec succès. Le solde de la caisse a été automatiquement mis à jour. Vous pouvez maintenant l\'imprimer.');
        } catch (\Exception $e) {
            Log::error('Erreur lors de la création du décaissement: ' . $e->getMessage());
            return back()
                ->withInput()
                ->with('error', 'Une erreur est survenue lors de l\'enregistrement du décaissement.');
        }
    }

    public function show($id)
    {
        $decaissement = DepenseCaisse::with(['operation', 'caisse', 'createur'])->findOrFail($id);
        $this->authorizeDecaissementAccess($decaissement);

        return view('tresorerie.decaissements-show', compact('decaissement'));
    }

    public function imprimer($id)
    {
        $decaissement = DepenseCaisse::with(['operation', 'caisse', 'createur'])->findOrFail($id);
        $this->authorizeDecaissementAccess($decaissement);

        // On récupère les paramètres de l'entreprise
        $entreprise = \App\Models\EntrepriseSettings::getActive();

        return view('tresorerie.decaissements-print', compact('decaissement', 'entreprise'));
    }

    public function edit($id)
    {
        $decaissement = DepenseCaisse::findOrFail($id);
        $this->authorizeDecaissementAccess($decaissement);

        /** @var User|null $user */
        $user = Auth::user();

        $caisses = Caisse::where('est_active', true)
            ->when($user && !in_array($user->role, ['admin', 'superadmin'], true), function ($query) use ($user) {
                $query->where('responsable_id', $user->id);
            })
            ->orderBy('nom')
            ->get();

        $approvedStatus = [
            'Approuvé_en_attente_paiement',
            'bon_pour_accord',
            'pret_execution',
            'approuvee',
            'approuve',
            'validée',
            'validee',
            'validé',
            'valide',
            'approved',
        ];

        $operations = collect();
        if (Schema::hasTable('operations') && Schema::hasColumn('operations', 'statut_courant')) {
            $operationsQuery = Operation::query()
                ->where(function ($query) use ($approvedStatus) {
                    $query->whereIn('statut_courant', $approvedStatus)
                        ->orWhereRaw('LOWER(TRIM(statut_courant)) IN (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', [
                            'approuve_en_attente_paiement',
                            'bon_pour_accord',
                            'pret_execution',
                            'approuvee',
                            'approuve',
                            'validée',
                            'validee',
                            'validé',
                            'valide',
                            'approved',
                        ]);
                });

            if (Schema::hasColumn('operations', 'is_paid')) {
                $operationsQuery->where(function ($query) use ($decaissement) {
                    $query->whereNull('is_paid')
                        ->orWhere('is_paid', false)
                        ->orWhere('id', $decaissement->operation_id);
                });
            }

            $operations = $operationsQuery->latest()->get();
        }

        return view('tresorerie.decaissements-edit', compact('decaissement', 'caisses', 'operations'));
    }

    public function update(Request $request, $id)
    {
        $decaissement = DepenseCaisse::findOrFail($id);
        $this->authorizeDecaissementAccess($decaissement);

        $validated = $request->validate([
            'operation_id' => 'nullable|exists:operations,id',
            'date_decaissement' => 'required|date',
            'libelle' => 'required|string|max:255',
            'montant' => 'required|numeric',
            'caisse_id' => 'required|exists:caisses,id',
        ]);

        if ((float) $validated['montant'] == 0.0) {
            return back()->withInput()->with('error', 'Le montant ne peut pas etre egal a zero.');
        }

        try {
            /** @var User|null $user */
            $user = Auth::user();
            $this->authorizeCaisseAccess(Caisse::findOrFail($validated['caisse_id']), $user);

            DB::transaction(function() use ($decaissement, $validated) {
                $montantOld = (float) $decaissement->montant;
                $montantNew = (float) $validated['montant'];
                $caisseOld = $decaissement->caisse_id;

                if ((int) $validated['caisse_id'] === (int) $caisseOld) {
                    // Meme caisse: delta solde attendu = ancien - nouveau
                    // Si negatif, la caisse sera debitee de |delta|.
                    $deltaSolde = $montantOld - $montantNew;
                    if ($deltaSolde < 0) {
                        $caisse = \App\Models\Caisse::findOrFail($caisseOld);
                        $soldeNeeded = abs($deltaSolde);
                        if ($caisse->solde_actuel < $soldeNeeded) {
                            throw new \Exception("Solde insuffisant dans la caisse '{$caisse->nom}'. "
                                . "Solde disponible: " . number_format((float) $caisse->solde_actuel, 0, ',', ' ') . " FCFA"
                            );
                        }
                    }
                } else {
                    // Changement de caisse:
                    // - ancienne caisse recoit +ancienMontant (peut debiter si ancienMontant < 0)
                    // - nouvelle caisse recoit -nouveauMontant (debite si nouveauMontant > 0)
                    $newCaisse = \App\Models\Caisse::findOrFail($validated['caisse_id']);
                    if ($montantNew > 0 && $newCaisse->solde_actuel < $montantNew) {
                        throw new \Exception("Solde insuffisant dans la nouvelle caisse '{$newCaisse->nom}'. "
                            . "Solde disponible: " . number_format((float) $newCaisse->solde_actuel, 0, ',', ' ') . " FCFA"
                        );
                    }

                    if ($montantOld < 0 && $caisseOld) {
                        $oldCaisse = \App\Models\Caisse::findOrFail($caisseOld);
                        $soldeNeededOld = abs($montantOld);
                        if ($oldCaisse->solde_actuel < $soldeNeededOld) {
                            throw new \Exception("Solde insuffisant dans l'ancienne caisse '{$oldCaisse->nom}' pour deplacer ce decaissement annule.");
                        }
                    }
                }

                // Mettre à jour le décaissement
                $decaissement->update([
                    'operation_id' => $validated['operation_id'] ?? null,
                    'date_depense' => $validated['date_decaissement'],
                    'libelle' => $validated['libelle'],
                    'montant' => $montantNew,
                    'caisse_id' => $validated['caisse_id'],
                ]);
            });

            return redirect()->route('tresorerie.decaissements.show', $decaissement->id)
                ->with('success', 'Décaissement mis à jour avec succès et le solde de la caisse a été ajusté.');
        } catch (\Exception $e) {
            Log::error('Erreur lors de la mise à jour du décaissement: ' . $e->getMessage());
            return back()
                ->withInput()
                ->with('error', $e->getMessage() ?: 'Une erreur est survenue lors de la mise à jour.');
        }
    }

    public function destroy($id)
    {
        $decaissement = DepenseCaisse::findOrFail($id);
        $this->authorizeDecaissementAccess($decaissement);

        $decaissement->delete();

        return redirect()->route('tresorerie.decaissements')
            ->with('success', 'Décaissement supprimé avec succès');
    }

    private function applyDecaissementVisibility($query, ?User $user)
    {
        if (!$user) {
            abort(403, 'Accès non autorisé');
        }

        if (in_array($user->role, ['admin', 'superadmin'], true)) {
            return $query;
        }

        // Les modérateurs ayant la permission tresorerie.access voient tous les décaissements
        if (in_array($user->role, ['moderator', 'moderateur'], true) && $user->hasModulePermission('tresorerie')) {
            return $query;
        }

        return $query->where(function ($innerQuery) use ($user) {
            $innerQuery->where('created_by', $user->id)
                ->orWhere('createur_id', $user->id)
                ->orWhereHas('caisse', function ($caisseQuery) use ($user) {
                    $caisseQuery->where('responsable_id', $user->id);
                });
        });
    }

    private function authorizeDecaissementAccess(DepenseCaisse $decaissement): void
    {
        /** @var User|null $user */
        $user = Auth::user();

        if (!$user) {
            abort(403, 'Accès non autorisé');
        }

        if (in_array($user->role, ['admin', 'superadmin'], true)) {
            return;
        }

        // Les modérateurs ayant la permission tresorerie.access ont accès complet
        if (in_array($user->role, ['moderator', 'moderateur'], true) && $user->hasModulePermission('tresorerie')) {
            return;
        }

        $isCreator = (int) ($decaissement->created_by ?? 0) === (int) $user->id
            || (int) ($decaissement->createur_id ?? 0) === (int) $user->id;
        $isResponsibleForCaisse = (int) optional($decaissement->caisse)->responsable_id === (int) $user->id;

        if (!$isCreator && !$isResponsibleForCaisse) {
            abort(403, 'Vous ne pouvez consulter que vos propres décaissements');
        }
    }

    /**
     * Marquer un chèque comme encaissé ou non
     */
    public function markEncashed(Request $request, $id)
    {
        $decaissement = DepenseCaisse::findOrFail($id);

        if (($decaissement->mode_paiement !== 'cheque' && empty($decaissement->numero_cheque)) || !$decaissement->numero_cheque) {
            return back()->with('error', 'Ce décaissement n\'est pas un paiement par chèque');
        }

        try {
            $decaissement->update([
                'est_encaisse' => !$decaissement->est_encaisse,
                'date_encaissement' => $decaissement->est_encaisse ? null : now(),
            ]);

            $message = $decaissement->est_encaisse 
                ? 'Chèque marqué comme encaissé'
                : 'Chèque marqué comme non encaissé';

            return back()->with('success', $message);
        } catch (\Exception $e) {
            return back()->with('error', 'Erreur : ' . $e->getMessage());
        }
    }

    private function authorizeCaisseAccess(Caisse $caisse, ?User $user): void
    {
        if (!$user) {
            abort(403, 'Accès non autorisé');
        }

        // Les admins et superadmins ont accès à toutes les caisses
        if (in_array($user->role, ['admin', 'superadmin'], true)) {
            return;
        }

        // Les modérateurs ayant la permission tresorerie peuvent utiliser toutes les caisses
        if (in_array($user->role, ['moderator', 'moderateur'], true) && $user->hasModulePermission('tresorerie')) {
            return;
        }

        // Les autres utilisateurs ne peuvent utiliser que leur propre caisse
        if ((int) $caisse->responsable_id !== (int) $user->id) {
            abort(403, 'Vous ne pouvez utiliser que votre propre caisse');
        }
    }
}
