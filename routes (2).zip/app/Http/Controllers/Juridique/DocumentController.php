<?php

namespace App\Http\Controllers\Juridique;

use App\Http\Controllers\Controller;
use App\Models\JuridiqueContrat;
use App\Models\JuridiqueDocument;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Storage;

class DocumentController extends Controller
{
    public function index()
    {
        $documents = Schema::hasTable('juridique_documents')
            ? JuridiqueDocument::with('contrat')->latest()->paginate(15)
            : new LengthAwarePaginator(collect(), 0, 15);

        return view('juridique.documents.index', compact('documents'));
    }

    public function create()
    {
        $contrats = Schema::hasTable('juridique_contrats')
            ? JuridiqueContrat::orderBy('titre')->get()
            : collect();

        return view('juridique.documents.create', compact('contrats'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'contrat_id' => 'nullable|exists:juridique_contrats,id',
            'reference' => 'nullable|string|max:100|unique:juridique_documents,reference',
            'titre' => 'required|string|max:255',
            'type_document' => 'nullable|string|max:100',
            'fichier' => 'nullable|file|mimes:pdf,doc,docx,xls,xlsx,ppt,pptx,csv,txt,jpg,jpeg,png,webp,zip,rar|max:10240',
            'piece_jointe' => 'nullable|file|mimes:pdf,doc,docx,xls,xlsx,ppt,pptx,csv,txt,jpg,jpeg,png,webp,zip,rar|max:10240',
            'date_document' => 'nullable|date',
            'date_expiration' => 'nullable|date',
            'statut' => 'nullable|string|max:50',
            'notes' => 'nullable|string',
        ]);

        $uploadedFile = $request->file('fichier') ?? $request->file('piece_jointe');
        if ($uploadedFile) {
            $validated['chemin_fichier'] = $uploadedFile->store('juridique/documents', 'public');
        }

        $validated['created_by'] = Auth::id();
        JuridiqueDocument::create($validated);

        return redirect()->route('juridique.documents.index')->with('success', 'Document enregistré avec succès.');
    }

    public function show(JuridiqueDocument $document)
    {
        if (Schema::hasTable('juridique_contrats')) {
            $document->load('contrat');
        }

        return view('juridique.documents.show', compact('document'));
    }

    public function edit(JuridiqueDocument $document)
    {
        $contrats = Schema::hasTable('juridique_contrats')
            ? JuridiqueContrat::orderBy('titre')->get()
            : collect();

        return view('juridique.documents.edit', compact('document', 'contrats'));
    }

    public function update(Request $request, JuridiqueDocument $document)
    {
        $validated = $request->validate([
            'contrat_id' => 'nullable|exists:juridique_contrats,id',
            'reference' => 'nullable|string|max:100|unique:juridique_documents,reference,' . $document->id,
            'titre' => 'required|string|max:255',
            'type_document' => 'nullable|string|max:100',
            'fichier' => 'nullable|file|mimes:pdf,doc,docx,xls,xlsx,ppt,pptx,csv,txt,jpg,jpeg,png,webp,zip,rar|max:10240',
            'piece_jointe' => 'nullable|file|mimes:pdf,doc,docx,xls,xlsx,ppt,pptx,csv,txt,jpg,jpeg,png,webp,zip,rar|max:10240',
            'date_document' => 'nullable|date',
            'date_expiration' => 'nullable|date',
            'statut' => 'nullable|string|max:50',
            'notes' => 'nullable|string',
        ]);

        $uploadedFile = $request->file('fichier') ?? $request->file('piece_jointe');
        if ($uploadedFile) {
            if ($document->chemin_fichier && Storage::disk('public')->exists($document->chemin_fichier)) {
                Storage::disk('public')->delete($document->chemin_fichier);
            }

            $validated['chemin_fichier'] = $uploadedFile->store('juridique/documents', 'public');
        }

        $document->update($validated);

        return redirect()->route('juridique.documents.index')->with('success', 'Document mis à jour avec succès.');
    }

    public function destroy(JuridiqueDocument $document)
    {
        if ($document->chemin_fichier && Storage::disk('public')->exists($document->chemin_fichier)) {
            Storage::disk('public')->delete($document->chemin_fichier);
        }

        $document->delete();
        return redirect()->route('juridique.documents.index')->with('success', 'Document supprimé avec succès.');
    }
}
